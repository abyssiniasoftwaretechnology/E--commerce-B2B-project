const express = require("express");
const router = express.Router();
const postController = require("../controllers/postController");
const upload = require("../middleware/uploads");

// CRUD routes with image upload
router.post("/", upload.array("images", 10), postController.createPost);

router.get("/filter", postController.filterPosts);
router.get("/search", postController.searchPosts);
router.get("/", postController.getPosts);
router.get("/:id", postController.getPostById);

router.put("/:id", upload.array("images", 10), postController.updatePost);

router.delete("/:id", postController.deletePost);
router.get("/item/:itemId", postController.getPostsByItem);
router.post("/:id/increment", postController.incrementPostView);

module.exports = router;
